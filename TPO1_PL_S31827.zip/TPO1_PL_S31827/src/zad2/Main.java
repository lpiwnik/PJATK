/**
 *
 *  @author Piwnik Łukasz s31827
 *
 */

package zad2;


public class Main {
  public static void main(String[] args) {
    String dirName = System.getProperty("user.home")+"/TPO1dir";
    String resultFileName = "TPO1res.txt";
    Futil.processDir(dirName, resultFileName);


  }
}
