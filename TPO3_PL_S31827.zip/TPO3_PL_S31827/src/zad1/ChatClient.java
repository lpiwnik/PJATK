/**
 *
 *  @author Piwnik Łukasz s31827
 *
 */

package zad1;


import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class ChatClient {
    private final String host;
    private final int port;
    private final String clientId;
    private Socket socket;
    private PrintWriter out;
    private final StringBuilder chatView = new StringBuilder();

    public ChatClient(String host, int port, String cid) {
        this.host = host;
        this.port = port;
        this.clientId = cid;
    }

    public void login() throws IOException{

        socket = new Socket(host, port);
        socket.setReuseAddress(true);
        out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);

        send(clientId + " logged in");
        Thread.ofVirtual().start(this::readMessages);
    }

    public void send(String msg) {
        if (out != null && !socket.isClosed()) {
            out.println(msg);
        }
    }

    public void logout() throws IOException {
        send(clientId + " logged out");
        socket.shutdownOutput();
    }

    private void readMessages() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            String line;
            while ((line = in.readLine()) != null) {
                synchronized (chatView) {
                    chatView.append(line).append("\n");
                }
                if (line.contains(clientId + " logged out")) {
                    break;
                }
                if (line.contains("ChatServer: chat closed")) {
                    break;
                }
            }
        } catch (IOException e) {

        }
    }

    public String getId() {
        return clientId;
    }

    public String getChatView() {
            return chatView.toString();
    }
}
